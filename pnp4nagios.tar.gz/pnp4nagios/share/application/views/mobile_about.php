<div data-role="content">
PNP4Nagios mobile interface based on jQuery Mobile
</div>

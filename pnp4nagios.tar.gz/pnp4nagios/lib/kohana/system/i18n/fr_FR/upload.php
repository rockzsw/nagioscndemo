<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
    'not_writable' => 'Le répertoire de destination pour l\'upload, %s, ne semble pas être accessible en écriture.',
);

<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group'   => 'Il gruppo %s non è definito nel file di configurazione.',
	'requires_mcrypt'   => 'L\'uso della libreria Encrypt richiede l\'abilitazione di mcrypt.',
	'no_encryption_key' => 'Per usare la libreria Encrypt bisogna definire una chiave di codifica nel file di configurazione.'
);

<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'not_writable' => 'The upload destination folder, %s, does not appear to be writable.',
);
<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group' => 'Группа %s не определена конфигурацией нумератора страниц.',
	'page'     => 'страница',
	'pages'    => 'страницы',
	'item'     => 'пункт',
	'items'    => 'пунктов',
	'of'       => 'из',
	'first'    => 'первая',
	'last'     => 'последняя',
	'previous' => 'предыдущая',
	'next'     => 'следующая',
);

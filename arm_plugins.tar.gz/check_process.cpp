/*
*检测进程信息
*
*
*
*/

#include "common.h"

#define PID_NAME        "rtx_v2"
#define PID_PATH        "/proc"
#define PID_STAT        "/proc/%u/stat"
#define PID_STATUS      "/proc/%u/status"
#define PID_EXEC        "/proc/%s/exe"
#define SPID_STAT       "/proc/%u/task/%u/stat"
#define SPID_STATUS     "/proc/%u/task/%u/status"

#define PROCESS_CPU    "/opt/nagios/cfg/process.cfg"

#define MEM_PATH         "/proc/meminfo"
#define CPU_TOTAL        "/proc/stat"

#define MAX_PID_NUM    128
//0:是需要监控的进程信息 后面的是这个进程下面的线程信息
PID_INFO_t tPidInfo[MAX_PID_NUM];
const char *pragrom = "check_process";
unsigned long long total_mem = 0;
unsigned long long total_cpu = 0;
double wValue[3]={0.0,0.0,0.0}; //cpu占用率，内存占用率 线程数
double cValue[3]={0.0,0.0,0.0};
double nValue[3]={0.0,0.0,0.0};
char *process = NULL;
int process_pid = -1; //主进程ID
int process_spid[128] = {0};//线程ID
int spid_num = 0;
TIC_t old_process_time = 0,old_total_cpu_time = 0;

static int get_pid_by_name(const char *pName,int *pid);//通过进程名获取进程号
static int get_pid(const char *path,int *spid);//获取某个进程下的所有线程
static int get_pid_stat_info(const char*filename,int num);//通过pid获取进程或线程的状态、cpu信息
static int get_pid_mem_info(const char*filename,int num);//通过pid获取主进程的内存信息
static int get_total_mem();//获取系统mem
static int get_total_cpu_time();//获取系统cpu时间
static void print_help();
static void print_usage();


static int 
get_old_processinfo(){

	char line[MIN_DATA_LEN+1];
	FILE *fp = NULL;
	if(!(fp = fopen(PROCESS_CPU,"r"))){
		return OK;
	}

	memset(line,0,sizeof line);
	while(fgets(line,MIN_DATA_LEN,fp)){

		if(EOF == sscanf(line,"%llu %llu",&old_process_time,&old_total_cpu_time)){
			old_process_time=old_total_cpu_time=0;
			break;
		}
	}

	fclose(fp);
	return OK;
}

static int 
flush_processinfo(){

	FILE *fp = NULL;

	if(!(fp = fopen(PROCESS_CPU,"w"))){
		printf("open file:%s for write error\n",PROCESS_CPU);
		return ERROR;
	}

	fprintf(fp,"%llu %llu\n",old_process_time,old_total_cpu_time);

	fclose(fp);
	return OK;
}


static int 
get_pid_by_name(const char *pName,int *pid){
	*pid = -1;
	DIR  *dir = NULL;
	struct dirent * d = NULL;
	int result = OK;

	if(!pName || !pid){
		printf("get_pid_by_name invalid arguments\n");
		return ERROR;
	}
		
	dir = opendir(PID_PATH);
	if(!dir){
		printf("open %s error\n",PID_PATH);
		return ERROR;
	}

	while((d = readdir(dir))){
		
		if(!strcmp(d->d_name,".") || !strcmp(d->d_name,".."))
			continue;
		
		char exe[MIN_DATA_LEN+1] = {0};
		char path[MIN_DATA_LEN+1] = {0};
		short len = 0;
		int temppid = 0;

		if(0 == (temppid = atoi(d->d_name)))
			continue;
		snprintf(exe,MIN_DATA_LEN,PID_EXEC,d->d_name);

		if(readlink(exe,path,MIN_DATA_LEN) < 0)
			continue;
	
		char *tempstr = strrchr(path,'/');
		tempstr += 1;
		
		len = strlen(tempstr);
		if(len < strlen(pName))
			continue;

		if(!strncmp(pName,tempstr,len)){
			if(tempstr[len] == ' '||tempstr[len] == '\0'){
				*pid = temppid;
				result = OK;
				break;
			}
		}
	}
	if(-1 == *pid){
		result = ERROR;
	}
	
	closedir(dir);
	return result;
}

static int 
get_pid(const char *path,int *spid){

	DIR *dir = NULL;
	struct dirent *d = NULL;
	int result = OK;
	int temppid = 0;

	if(!path || !spid){
		printf("get_thread_pid invalid arguments\n");
		return ERROR;
	}

	dir = opendir(path);
	if(!dir){
		printf("open dir %s error\n",path);
		return ERROR;
	}

	while((d = readdir(dir))){

		if(!strcmp(d->d_name,".") || !strcmp(d->d_name,".."))
			continue;

		if((temppid = atoi(d->d_name)) <= 0)
			continue;

		*spid = temppid;
		spid ++;
	}

	return result;
	
}

static int 
get_pid_stat_info(const char*filename,int num){

	int result = OK;
	FILE *fp = NULL;
	char line[MIN_DATA_LEN+1] = {0};

	if(!filename || num < 0 || num >= MAX_PID_NUM){
		printf("get pid info invalid argument num:%d\n",num);
		return ERROR;
	}
	
	fp = fopen(filename,"r");
	if(!fp){
		printf("open file:%s error\n",filename);
		return ERROR;
	}

	if(!fgets(line,MIN_DATA_LEN,fp)){
		printf("get file:%s info error\n",filename);
		fclose(fp);
		return ERROR;
	}

	if(sscanf(line,"%*d (%s",tPidInfo[num].pid_name) == EOF){
		printf("error 1\n");
		fclose(fp);
		return ERROR;
	}

	int len = strlen(tPidInfo[num].pid_name);
	while(tPidInfo[num].pid_name[len-1] == ')' || tPidInfo[num].pid_name[len-1] == ' '){
		len--;
	}

	tPidInfo[num].pid_name[len] = '\0';

	if(EOF == sscanf(line,"%*d %*s %c %*d %*d %*d %*d %*d %*u %*u %*u %*u %*u %llu %llu %llu %llu",&tPidInfo[num].pid_status,&tPidInfo[num].u,&tPidInfo[num].s,&tPidInfo[num].uw,&tPidInfo[num].sw)){
		printf("error \n");
		fclose(fp);
		return ERROR;
	}
	fclose(fp);
	return result;
}

static int 
get_pid_mem_info(const char*filename,int num){

	int result = OK;
	FILE * fp = NULL;
	char line[MIN_DATA_LEN+1] = {0};

	if(!filename || num < 0 || num >= MAX_PID_NUM){
		printf("get pid info invalid argument num:%d\n",num);
		return ERROR;
	}

	if(!(fp = fopen(filename,"r"))){
		printf("open file:%s error\n",filename);
		return ERROR;
	}
	
	
	while(fgets(line,MIN_DATA_LEN,fp)){
		if(!strncmp(line,"VmRSS:",6)){
			sscanf(line+6,"%llu",&tPidInfo[num].m);
			result = OK;
			break;
		}
	}

	fclose(fp);
	return result;
}

static int 
get_total_mem(){
	int result = OK;
	FILE *fp = NULL;
	char line[MIN_DATA_LEN+1] = {0};

	if(!(fp = fopen(MEM_PATH,"r"))){
		printf("open file:%s error\n",MEM_PATH);
		return ERROR;
	}

	while(fgets(line,MIN_DATA_LEN,fp)){

		if(!strncmp(line,"MemTotal:",9)){
			sscanf(line+9,"%llu",&total_mem);
			result = OK;
			break;
		}
	}

	fclose(fp);
	return result;
}

static int 
get_total_cpu_time(){
	int result = OK;
	FILE *fp = NULL;
	char line[MIN_DATA_LEN+1] = {0};

	if(!(fp = fopen(CPU_TOTAL,"r"))){
		printf("open file:%s error\n",CPU_TOTAL);
		return ERROR;
	}

	if(fgets(line,MIN_DATA_LEN,fp)){
		sscanf(line,"cpu  %*llu %*llu %*llu %llu",&total_cpu);
		result  = OK;
	}

	fclose(fp);
	return result;
}

static void 
get_value(char *arg,double *th)
{
	size_t i = 0,n = 0;
	char *str = arg,*p = NULL;

	n = strlen(arg);
	for(;i < 3;i++){
		th[i] = strtod(str,&p);
		if(p == str)
			break;

		str = p+1;
		if(n <= (size_t)(str-arg))
			break;
	}
}

static int 
process_arguments(int argc,char *argv[])
{
	int c = 0;

	int options = 0;
	static struct option longopts[] = {
		{"warning",required_argument,0,'w'},
		{"critical",required_argument,0,'c'},
		{"thread_num",required_argument,0,'n'},
		{"help",required_argument,0,'h'},
		{0,0,0,0}
	};

	if(argc < 2)
		return ERROR;

	while(1)
	{
		c = getopt_long(argc,argv,"w:c:h",longopts,&options);
		if(-1 == c || EOF == c)
			break;

		switch(c)
		{
		case 'w':
			get_value(optarg,wValue);
			break;
		case 'c':
			get_value(optarg,cValue);
			break;
		case 'n':
			process = strdup(optarg);
			break;
		case 'h':
			print_help();
			exit(STATE_OK);
		default:
			break;
		}
	}

	return OK;
}

int 
main(int argc,char *argv[]){
	//定义参数		
	int result = STATE_OK,i = 0;
	char stat_line[MIN_DATA_LEN+1] = {0};
	char line[MIN_DATA_LEN+1] = {0};
	char *temp_name = (char*)PID_NAME;

	memset(&tPidInfo,0,sizeof tPidInfo);
	memset(process_spid,0,sizeof process_spid);
	// 字符集编码方式
	setlocale(LC_ALL,"");
	setlocale(LC_NUMERIC,"POSIX");//小数点定义以posix

	if(ERROR == process_arguments(argc,argv)){
		printf("invaliad parameter about program:%s\n",pragrom);
		result = STATE_UNKNOWN;
		goto END;
	}

	get_old_processinfo();

	if(ERROR == get_total_mem()){
		printf("get_total_mem error\n");
		result = STATE_UNKNOWN;
		goto END;
	}

	if(ERROR == get_total_cpu_time()){
		printf("get_total_cpu_time error\n");
		result = STATE_UNKNOWN;
		goto END;
	}
	
	if(process)
		temp_name = process;

	if(ERROR == get_pid_by_name(temp_name,&process_pid)){
		printf("get pid by name:%s error\n",temp_name);
		result = STATE_UNKNOWN;
		goto END;
	}
	memset(line,0,sizeof line);
	memset(process_spid,0,sizeof process_spid);
	snprintf(line,MIN_DATA_LEN,"/proc/%d/task",process_pid);
	if(ERROR == get_pid(line,process_spid)){
		printf("ger spid from %s error\n",line);
		result = STATE_UNKNOWN;
		goto END;
	}
	
	for(;;i++){
		memset(line,0,sizeof line);
		if(0 == i){
			tPidInfo[i].pid = process_pid;
			snprintf(line,MIN_DATA_LEN,PID_STAT,tPidInfo[i].pid);
		}
		else{
			tPidInfo[i].pid = process_spid[i-1];
			snprintf(line,MIN_DATA_LEN,SPID_STAT,process_pid,tPidInfo[i].pid);
		}

		if(0 == tPidInfo[i].pid)
			break;

		if(ERROR == get_pid_stat_info(line,i)){
			printf("get pid stat[%d]:%s info error\n",i,line);
			result = STATE_UNKNOWN;
			goto END;
		}

		if(0 == i){
			memset(line,0,sizeof line);
			snprintf(line,MIN_DATA_LEN,PID_STATUS,process_pid);
			if(ERROR == get_pid_mem_info(line,i)){
				printf("get pid status:%s info error\n",line);
				result = STATE_UNKNOWN;
				goto END;
			}
		}
		else{
			tPidInfo[i].m = tPidInfo[0].m;
		}
		spid_num++;	
	}
	
	nValue[0] = (double)(tPidInfo[0].s + tPidInfo[0].sw + tPidInfo[0].u + tPidInfo[0].uw - old_process_time)/(total_cpu-old_total_cpu_time);
	nValue[1] = (double)tPidInfo[0].m/total_mem;
	nValue[2] = spid_num;

	old_process_time = tPidInfo[0].s + tPidInfo[0].sw + tPidInfo[0].u + tPidInfo[0].uw;
	old_total_cpu_time = total_cpu;

	for(i = 0 ;i < 3;i++){
		if(nValue[i] > wValue[i]){
			result = STATE_WARNING;
			if(nValue[i] > cValue[i]){
				result = STATE_CRITICAL;
				break;
			}				
		}
	}

	snprintf(stat_line,sizeof stat_line,"process:%s:status:%c--%.2lf %.2lf %.2lf",tPidInfo[0].pid_name,tPidInfo[0].pid_status,nValue[0],nValue[1],nValue[2]);
	printf("%s-%s\n",state_text(result),stat_line);
	for(i = 1;i<spid_num;i++){	
		double cpuinfo = (double)(tPidInfo[i].s + tPidInfo[i].sw + tPidInfo[i].u + tPidInfo[i].uw)/total_cpu;
		if(cpuinfo > 0.001)
			printf("thread pid:%u name:%s status:%c cpu:%.2f\n",tPidInfo[i].pid,tPidInfo[i].pid_name,tPidInfo[i].pid_status,cpuinfo);
	}
	putchar('|');

	printf("load:nValue %.2lf %.2lf %.2lf",nValue[0],nValue[1],nValue[2]);
	printf(" wValue %.2lf %.2lf %.2lf",wValue[0],wValue[1],wValue[2]);
	printf(" cValue %.2lf %.2lf %.2lf",cValue[0],cValue[1],cValue[2]);
	
END:
	if(process)
		free(process);
	if(ERROR == flush_processinfo()){
		printf("flush process info error about pragrom:%s\n",pragrom);
		result = STATE_UNKNOWN;
	}
	return result;
}

static void 
print_help(){

	printf ("%s\n", "This plugin checks the status of process");
	printf ("\n\n");

	print_usage();

	printf (" %s\n", "-w, --warning=PERCENT% PERCENT% INTEGER");
	printf ("    %s\n", "Exit with WARNING status if less than  process cpu mem and thread num");
	printf (" %s\n", "-c, --critical=PERCENT% PERCENT% INTEGER");
	printf ("    %s\n", "Exit with CRITICAL status if less than process cpu mem and thread num");
	printf (" %s\n", "-c, --process=STRING");
	printf ("    %s\n", "get process name");

}

static void
print_usage(void)
{
	printf ("%s\n", "WARNING: check_cpu");
	printf ("%s\n", "Usage:");
	printf(" %s  [-w <warn>] [-c <crit>] [-h <help>]\n", pragrom);
}

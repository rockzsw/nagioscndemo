#include "common.h"

int main(int argc,char *argv[])
{	
	//
	if(argc != 5 || !argv[1] || !argv[2] || !argv[3] || !argv[4]){
		printf("invaliad arguments\n");
		return STATE_UNKNOWN;
	}

	pid_t pid = fork();
	if(0 == pid)
	{
		execl(argv[1],argv[1],argv[2],argv[3],argv[4],NULL);
		exit(0);
	}
	
	return STATE_OK;
}
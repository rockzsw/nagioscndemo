
#include "common.h"

#define LOG_PATH  "/mnt/sd/rtx/error.log"
#define DB_BACK_PATH "/home/rtx/terminal.db_bak"
#define CORE_DUMP_PATH "/mnt/sd/core"


typedef struct FILE_INFO_T{
	unsigned int filezie;//BYTE
	time_t       mfiletime;//last modify time	
}FILE_INFO_T;

struct FILE_INFO_T tCoreInfo[10]={0}; //coredump 信息
struct FILE_INFO_T tLogInfo = {0};//日志 信息
struct FILE_INFO_T tDBBackInfo = {0};//备份数据库信息
unsigned char coreFileNum = 0;//coredump 数目
unsigned wCoreFileNum = 0;//阈值
unsigned cCoreFileNum = 0;
const char *pragrom = "check_file";

static int get_file_info(const char *path,struct stat *statbuf); //获取文件的详细信息
static int get_coredump_info();
static int get_dbback_info();
static int get_log_info();
static void print_help();
static void print_usage();

static int 
process_arguments(int argc,char *argv[])
{
	int c = 0;

	int options = 0;
	static struct option longopts[] = {
		{"warning",required_argument,0,'w'},
		{"critical",required_argument,0,'c'},
		{"help",required_argument,0,'h'},
		{0,0,0,0}
	};

	if(argc < 2)
		return ERROR;

	while(1)
	{
		c = getopt_long(argc,argv,"w:c:h",longopts,&options);
		if(-1 == c || EOF == c)
			break;

		switch(c)
		{
		case 'w':
			wCoreFileNum = atoi(optarg);
			break;
		case 'c':
			cCoreFileNum = atoi(optarg);
			break;
		case 'h':
			print_help();
			exit(STATE_OK);
		default:
			break;
		}
	}

	return OK;
}

static int 
get_file_info(const char *path,struct stat *statbuf)
{
	if(-1 == stat(path,statbuf))
		return ERROR;
	return OK;
}

static int
get_coredump_info()
{
	//
	DIR *dirp = NULL;
	char longpath[128] = {0};
	struct dirent  *dp = NULL;
	struct stat statbuf = {0};

	//
	if(NULL == (dirp = opendir(CORE_DUMP_PATH)))
		return ERROR;
	
	//
	while((dp = readdir(dirp))){

		if('.' == dp->d_name[0] || 0 != memcmp(dp->d_name,"core.",5))
			continue;
		
		memset(longpath,0,sizeof longpath);
		snprintf(longpath,sizeof longpath,"%s/%s",CORE_DUMP_PATH,dp->d_name);

		memset(&statbuf,0,sizeof statbuf);
		if(ERROR == get_file_info(longpath,&statbuf)){
			closedir(dirp);
			return ERROR;
		}
			
		tCoreInfo[coreFileNum].filezie = statbuf.st_size;
		tCoreInfo[coreFileNum].mfiletime = statbuf.st_mtime;
		coreFileNum++;
	}
	//
	closedir(dirp);
	return OK;
}

static int
get_log_info()
{
	//
	struct stat statbuf = {0};
	if(ERROR == get_file_info(LOG_PATH,&statbuf))
		return ERROR;
	//
	tLogInfo.filezie = statbuf.st_size;
	tLogInfo.mfiletime = statbuf.st_mtime;

	return OK;
}

static int
get_dbback_info()
{
	//
	struct stat statbuf = {0};
	if(ERROR == get_file_info(DB_BACK_PATH,&statbuf))
		return ERROR;
	//
	tDBBackInfo.filezie = statbuf.st_size;
	tDBBackInfo.mfiletime = statbuf.st_mtime;

	return OK;
}

int main(int argc,char ** argv)
{
	//定义参数		
	int result = STATE_OK,i = 0;
	int coreFileState = OK,logFileState = OK,dbBackFileState = OK;

	setlocale(LC_ALL,"");
	setlocale(LC_NUMERIC,"POSIX");


	//参数解析
	if(ERROR == process_arguments(argc,argv)){
		printf("invaliad parameter about program:%s\n",pragrom);
		return STATE_UNKNOWN;
	}

	//获取cordump文件信息
	coreFileState = get_coredump_info();

	//获取log文件信息
	logFileState = get_log_info();

	//获取数据库备份文件信息
	dbBackFileState = get_dbback_info();

	if(coreFileNum > wCoreFileNum){
		result = STATE_WARNING;
		if(coreFileNum > cCoreFileNum)
			result = STATE_CRITICAL;
	}//

	int nLen = 0;

	printf("%s get core:%s get log:%s get db:%s\n",state_text(result),state_text(coreFileState),state_text(logFileState),state_text(dbBackFileState));	
	printf("core file num:%d\n",coreFileNum);
	for(i=0 ;i < coreFileNum ; i++){
		printf("corefile info:size(%d)byte--mtime(%s)\n",tCoreInfo[i].filezie,ctime(&tCoreInfo[i].mfiletime));
	}
	if(ERROR != logFileState)
		printf("log file info:size(%d)byte--mtime(%s)\n",tLogInfo.filezie,ctime(&tLogInfo.mfiletime));
	if(ERROR != dbBackFileState)
		printf("dbbcak file info:size(%d)byte--mtime(%s)\n",tDBBackInfo.filezie,ctime(&tDBBackInfo.mfiletime));

	putchar('|');
	printf("load:cur--%d warning--%d critical--%d\n",coreFileNum,wCoreFileNum,cCoreFileNum);
	return result;
}

static void 
print_help(){

	printf ("%s\n", "This plugin checks the status of file about coredump log and db");
	printf ("\n\n");

	print_usage();

	printf (" %s\n", "-w, --warning=INTEGER");
	printf ("    %s\n", "Exit with WARNING status if less than INTEGER of coredump file num");
	printf (" %s\n", "-c, --critical=INTEGER");
	printf ("    %s\n", "Exit with CRITICAL status if less than PERCENT of coredump file num");

}

static void
print_usage(void)
{
	printf ("%s\n", "WARNING: check_file");
	printf ("%s\n", "Usage:");
	printf(" %s  [-w <warn>] [-c <crit>] [-h <help>]\n", pragrom);
}

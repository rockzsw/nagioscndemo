#include "common.h"

#define NUM_ARGUMENTS   2

static int 
get_file_info(const char *path,struct stat *statbuf)
{
	if(-1 == stat(path,statbuf))
		return ERROR;
	return OK;
}
static int is_file_exit(const char *path)
{
	FILE *fp = fopen(path,"r");
	if(!fp)
		return false;
	fclose(fp);
	return true;
}

int main(int argc,char *argv[])
{
	if(argc < NUM_ARGUMENTS){
		printf("mtime:\n");
		return ERROR;
	}

	struct stat statbuf = {0};
	if(!is_file_exit(argv[1])){
		printf("mtime:\n");
		return ERROR;
	}
	if(ERROR == get_file_info(argv[1],&statbuf)){
		printf("mtime:\n");
		return ERROR;
	}
	printf("mtime:%ld",statbuf.st_mtime);
	return OK;
}
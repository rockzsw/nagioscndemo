#ifndef __COMMON_H_
#define _COMMON_H_
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <getopt.h>
#include <locale.h>
#include <dirent.h>
#include <errno.h>       //for errno  
#include <fcntl.h> 
#include <time.h>
#include <dirent.h>
#include <ifaddrs.h>
#include <sys/ioctl.h>
#include <linux/if.h>
#include <sys/time.h>

enum {
	OK = 0,
	ERROR = -1
};

enum {
	STATE_OK,
	STATE_WARNING,
	STATE_CRITICAL,
	STATE_UNKNOWN,
	STATE_DEPENDENT
};
#ifndef TIC_t
typedef unsigned long long TIC_t;
#endif

#define MIN_DATA_LEN  255+1

typedef struct CPU_t {
	TIC_t u, n, s, i, w, x, y, z; // as represented in /proc/stat
	TIC_t u_sav, s_sav, n_sav, i_sav, w_sav, x_sav, y_sav, z_sav; // in the order of our display
	unsigned id;  // the CPU ID number
} CPU_t;

typedef struct pid_info_t{
	int pid;
	char pid_name[MIN_DATA_LEN+1];
	char pid_status;//R:running S:sleeping D:disk sleep
	TIC_t u,s,uw,sw;
	TIC_t m; // use memory
}PID_INFO_t;


typedef struct disk_info_t{
	char disk_name[MIN_DATA_LEN+1];
	char mount_path[MIN_DATA_LEN+1];
	TIC_t total;
	TIC_t used;
}DISK_INFO_t;


typedef struct network_info_t{
	char cindex;//Ŀǰ��ʾ1��2
	char status;//1:up,0:down
	char bwifi;//1:wifi,0:no
	int  levels;//wifi �ź�
	TIC_t dw_ex_io;//�������в�ֵ
	TIC_t dw_total_io;//����������ֵ
	unsigned long dw_tick;//ʱ��
	unsigned long dw_total_tick;//�ܹ�����
}NETWORK_INFO_t;

const char * 
state_text(int result);

int 
strpos(const char *haystack,const char *needle) ;


#endif
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>


void debug_function(int argc)
{
	int i = 0;
	for(;i<argc;i++)
	{
		printf("hello world %d\n",i);
	}
}

void * thread_info(void * argv)
{
	int num = *(int *)argv;
	int i = 0;
	for(;i < num; i++)
	{
		printf("thread hello world %d\n",i);
	}
}

int main(void)
{
	int num = 5;
	debug_function(num);
	printf("你好\n");

	return 0;
}

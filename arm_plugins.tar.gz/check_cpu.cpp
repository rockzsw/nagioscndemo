
#include "common.h"

#define _CPU_STAT_INFO  "/proc/stat"
#define _CPU__OLD_STAT_INFO "/opt/nagios/cfg/cpuinfo.cfg"
#define VALUE_NUM    5

char msgBuf[MIN_DATA_LEN+1];
double cpuasge[VALUE_NUM]={0.0,0.0,0.0,0.0,0.0};//0:长期平均cpu利用率,1;峰值cpu利用率-根据获取时间间隔,2:用户态cpu利用率,3:内核态cpu利用率,4:io空转
CPU_t tCpu = {0};
double wValue[VALUE_NUM]={0.0,0.0,0.0,0.0,0.0};//报警程度 需要客户自己配置
double cValue[VALUE_NUM]={0.0,0.0,0.0,0.0,0.0};//危急程度 需要客户自己配置
const char *pragrom = "check_cpu";


static void get_oldcpuinfo();
static void flush_oldcpuinfo();
static int get_newcpuinfo();
static void print_help();
static void print_usage();


static void 
get_oldcpuinfo()
{
	memset(&tCpu,0,sizeof tCpu);
	FILE *fp = fopen(_CPU__OLD_STAT_INFO,"r");
	if(fp){
		fscanf(fp,"cpu %llu %llu %llu %llu %llu",&tCpu.u_sav,&tCpu.n_sav,&tCpu.s_sav,&tCpu.i_sav,&tCpu.w_sav);
		tCpu.u_sav = tCpu.n_sav = tCpu.s_sav = tCpu.w_sav = tCpu.i_sav = 0;
		fclose(fp);
	}
	fp = NULL;
}

static void 
flush_oldcpuinfo()
{
	FILE * fp = fopen(_CPU__OLD_STAT_INFO,"w+");
	if(fp){

		fprintf(fp,"cpu %llu %llu %llu %llu %llu",tCpu.u_sav,tCpu.n_sav,tCpu.s_sav,tCpu.i_sav,tCpu.w_sav);
		fflush(fp);
		fclose(fp);
	}
	fp = NULL;
}

static int
get_newcpuinfo()
{
	FILE *fp = fopen(_CPU_STAT_INFO,"r");
	if(fp){
		memset(msgBuf,0,sizeof msgBuf);
		if(fgets(msgBuf,MIN_DATA_LEN,fp))
			sscanf(msgBuf,"cpu  %llu %llu %llu %llu %llu",&tCpu.u,&tCpu.n,&tCpu.s,&tCpu.i,&tCpu.w);
		else{
			fclose(fp);
			return ERROR;
		}
			
		fclose(fp);
		return OK;
	}
	return ERROR;
}

static void 
get_value(char *arg,double *th)
{
	size_t i = 0,n = 0;
	char *str = arg,*p = NULL;

	n = strlen(arg);
	for(;i < VALUE_NUM;i++){
		th[i] = strtod(str,&p);
		if(p == str)
			break;

		str = p+1;
		if(n <= (size_t)(str-arg))
			break;
	}
}

static int 
process_arguments(int argc,char *argv[])
{
	int c = 0;

	int options = 0;
	static struct option longopts[] = {
		{"warning",required_argument,0,'w'},
		{"critical",required_argument,0,'c'},
		{"help",required_argument,0,'h'},
		{0,0,0,0}
	};

	if(argc < 2)
		return ERROR;

	while(1)
	{
		c = getopt_long(argc,argv,"w:c:h",longopts,&options);
		if(-1 == c || EOF == c)
			break;

		switch(c)
		{
		case 'w':
			get_value(optarg,wValue);
			break;
		case 'c':
			get_value(optarg,cValue);
			break;
		case 'h':
			print_help();
			exit(STATE_OK);
		default:
			break;
		}
	}

	return OK;
}


int main(int argc,char *argv[])
{
	//定义参数		
	int result = STATE_OK,i = 0;
	char stat_line[MIN_DATA_LEN+1] = {0};

	// 字符集编码方式
	setlocale(LC_ALL,"");
	setlocale(LC_NUMERIC,"POSIX");//小数点定义以posix

	//获取之前保存的cpu信息 可以没有
	get_oldcpuinfo();

	if(ERROR == process_arguments(argc,argv)){
		printf("invaliad parameter about program:%s\n",pragrom);
		return STATE_UNKNOWN;
	}

	if(ERROR == get_newcpuinfo()){
		printf("nonsupport get cpu info about program:%s\n",pragrom);
		return STATE_UNKNOWN;
	}
	

	//终端总共cpu使用率
	double used_cpu = tCpu.s+tCpu.u + tCpu.n;
	double total_cpu = tCpu.s  + tCpu.i+tCpu.w +tCpu.n + tCpu.u;
	cpuasge[0] = used_cpu/total_cpu;

	//终端峰值cpu使用率
	double used_save_cpu = tCpu.s_sav+tCpu.u_sav+tCpu.n;
	double total_save_cpu = tCpu.s_sav + tCpu.i_sav+tCpu.w_sav +tCpu.n_sav + tCpu.u_sav;
	if(used_cpu < used_save_cpu || total_cpu < total_save_cpu){
		used_save_cpu = total_save_cpu = 0;
	}
	double dwused_cpu = used_cpu-used_save_cpu;
	double dwtotal_cpu = total_cpu-total_save_cpu;
	if(dwused_cpu < 0)
		dwused_cpu = 0;
	if(dwtotal_cpu <= 0 )
		dwtotal_cpu = 1;
	cpuasge[1] = (dwused_cpu)/(dwtotal_cpu);

	//终端用户态cpu使用率
	double user_cpu = (double)tCpu.u;
	cpuasge[2] = (user_cpu)/(total_cpu);

	//终端内核态cpu使用率
	double sys_cpu = (double)tCpu.s;
	cpuasge[3] = (sys_cpu)/(total_cpu);

	//终端io空转率
	double io_cpu = (double)tCpu.w;
	cpuasge[4] = (io_cpu)/(total_cpu);

	//将新的cpu信息保存起来
	tCpu.u_sav = tCpu.u;
	tCpu.s_sav = tCpu.s;
	tCpu.n_sav = tCpu.n;
	tCpu.i_sav = tCpu.i;
	tCpu.w_sav = tCpu.w;
	flush_oldcpuinfo();
	
	for(;i < VALUE_NUM;i++){
		if(cpuasge[i] >= wValue[i]){
			result = STATE_WARNING;
			if(cpuasge[i] > cValue[i]){
				result = STATE_CRITICAL;
				break;
			}
		}
	}
	
	snprintf(stat_line,sizeof stat_line,"cpuasge:%.2lf %.2lf %.2lf %.2lf %.2lf",cpuasge[0],cpuasge[1],cpuasge[2],cpuasge[3],cpuasge[4]);

	printf("%s-%s|",state_text(result),stat_line);

	for(i = 0;i < VALUE_NUM; i++){
		printf("load %.2lf:%.2lf:%.2lf  ",cpuasge[i],wValue[i],cValue[i]);
	}
	putchar('\n');
	return result;
}

static void 
print_help(){

	printf ("%s\n", "This plugin checks the status of cpu");
	printf ("\n\n");

	print_usage();

	printf (" %s\n", "-w, --warning=PERCENT%");
	printf ("    %s\n", "Exit with WARNING status if less than PERCENT of cpu");
	printf (" %s\n", "-c, --critical=PERCENT%");
	printf ("    %s\n", "Exit with CRITICAL status if less than PERCENT of cpu");

}

static void
print_usage(void)
{
	printf ("%s\n", "WARNING: check_cpu");
	printf ("%s\n", "Usage:");
	printf(" %s  [-w <warn>] [-c <crit>] [-h <help>]\n", pragrom);
}

#include "common.h"

#define TAG_DCD    "DCD"
#define TAG_RXD    "RXD"
#define TAG_TXD    "TXD"
#define TAG_DTR    "DTR"
#define TAG_SG     "SG"
#define TAG_DSR    "DSR"
#define TAG_RTS    "RTS"
#define TAG_CTS    "CTS"
#define TAG_RI     "RI"

#define TAG_TX     "tx:"

#define PATH_SERIAL_PATH    "/proc/tty/driver/atmel_serial"
#define TAG_SERIAL          "3: uart:ATMEL_SERIAL"
#define FILE_NAME           "/opt/nagios/cfg/serial.cfg"

double wValue[1] = {0.0};
double cValue[1] = {0.0};
const char *pragrom = "check_serial";

TIC_t tx = 0,rx = 0,txold = 0,rxold = 0;
unsigned long tick = 0,tickold = 0;

static int get_old_serialinfo();
static int flush_serialinfo();
static int get_serial_info(); //
static void print_help();
static void print_usage();

static int 
get_old_serialinfo(){

	char line[MIN_DATA_LEN+1];
	FILE *fp = NULL;
	if(!(fp = fopen(FILE_NAME,"r"))){
		return OK;
	}

	memset(line,0,sizeof line);
	while(fgets(line,MIN_DATA_LEN,fp)){
	
		if(EOF == sscanf(line,"%llu %llu %lu",&txold,&rxold,&tickold)){
			txold = rxold = 0;
			tickold = 0;
			break;
		}
	}

	fclose(fp);
	return OK;
}

static int 
flush_serialinfo(){

	FILE *fp = NULL;

	if(!(fp = fopen(FILE_NAME,"w"))){
		printf("open file:%s for write error\n",FILE_NAME);
		return ERROR;
	}

	fprintf(fp,"%llu %llu %lu\n",txold,rxold,tickold);

	fclose(fp);
	return OK;
}

static int 
get_serial_info(){
	int result = ERROR;
	FILE *fp = NULL;
	char line[MIN_DATA_LEN+1];

	if(!(fp = fopen(PATH_SERIAL_PATH,"r"))){
		printf("open file:%s error\n",PATH_SERIAL_PATH);
		return result;
	}

	struct timeval tv = {0};
	gettimeofday(&tv,NULL);
	tick = tv.tv_sec;

	memset(line,0,sizeof line);
	while(fgets(line,MIN_DATA_LEN,fp)){
		if(!strncmp(line,TAG_SERIAL,strlen(TAG_SERIAL))){
			//
			if(strstr(line,TAG_RTS) && strstr(line,TAG_CTS) && strstr(line,TAG_DTR) && strstr(line,TAG_DSR)){
				
				char *ptr = strstr(line,TAG_TX);
				if(ptr){
					if(EOF == sscanf(ptr,"tx:%llu rx:%llu",&tx,&rx)){
						printf("get infomation error\n");
						break;
					}
					result = OK;
				}
				break;
			}
		}
	}

	fclose(fp);
	return result;
}

static void 
get_value(char *arg,double *th)
{
	size_t i = 0,n = 0;
	char *str = arg,*p = NULL;

	n = strlen(arg);
	for(;i < 3;i++){
		th[i] = strtod(str,&p);
		if(p == str)
			break;

		str = p+1;
		if(n <= (size_t)(str-arg))
			break;
	}
}

static int 
process_arguments(int argc,char *argv[])
{
	int c = 0;

	int options = 0;
	static struct option longopts[] = {
		{"warning",required_argument,0,'w'},
		{"critical",required_argument,0,'c'},
		{"help",required_argument,0,'h'},
		{0,0,0,0}
	};

	if(argc < 2)
		return ERROR;

	while(1)
	{
		c = getopt_long(argc,argv,"w:c:h",longopts,&options);
		if(-1 == c || EOF == c)
			break;

		switch(c)
		{
		case 'w':
			get_value(optarg,wValue);
			break;
		case 'c':
			get_value(optarg,cValue);
			break;
		case 'h':
			print_help();
			exit(STATE_OK);
		default:
			break;
		}
	}

	return OK;
}


int main(int argc,char *argv[]){

	int result = STATE_OK;
	char stat_line[MIN_DATA_LEN+1] = {0};
	double data = 0,tmptick = 0;
	double status = 0;

	if(ERROR == process_arguments(argc,argv)){
		printf("invaliad parameter about program:%s\n",pragrom);
		result = STATE_UNKNOWN;
		goto END;
	}

	get_old_serialinfo();

	if(ERROR == get_serial_info()){
		printf("get serial info error about program:%s\n",pragrom);
		result = STATE_UNKNOWN;
		goto END;
	}
	
	if(tx < txold || rx < rxold){
		rxold = txold = 0;
	}
	data = tx+rx-rxold-txold;

	if(tick < tmptick){
		tickold = 0;
	}
	tmptick = tick-tickold;
	

	status = data/tmptick;
	rxold = rx;
	txold = tx;
	tickold = tick;

	/*if(status > wValue[0]){
		result = STATE_WARNING;
		if(status > cValue[0])
			result = STATE_CRITICAL;
	}*/

	snprintf(stat_line,sizeof stat_line,"serial info:%.2f(b/s)",status);
	printf("%s-%s\n",state_text(result),stat_line);
	printf("serial info:tx:%llu(b) rx:%llu(b) data:%2f tick:%2f|",tx,rx,data,tmptick);

END:
	if(ERROR == flush_serialinfo()){
		printf("flush serial info error about pragrom:%s\n",pragrom);
		result = STATE_UNKNOWN;
	}
	return result;

}

static void 
print_help(){

	printf ("%s\n", "This plugin checks the status of serial");
	printf ("\n\n");

	print_usage();

	printf (" %s\n", "-w, --warning=PERCENT%");
	printf ("    %s\n", "Exit with WARNING status if less than PERCENT of speed");
	printf (" %s\n", "-c, --critical=PERCENT%");
	printf ("    %s\n", "Exit with CRITICAL status if less than PERCENT of speed");
	
}

static void
print_usage(void)
{
	printf ("%s\n", "WARNING: check_serial ");
	printf ("%s\n", "Usage:");
	printf(" %s  [-w <warn>] [-c <crit>] [-h <help>] \n", pragrom);
}
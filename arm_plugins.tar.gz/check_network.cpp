
#include "common.h"

#define DEV_ETH0       "eth0"
#define DEV_ETH1       "eth1"
#define INDEX_ETH0     1
#define INDEX_ETH1     2

#define CMD_IWCONFIG   "iwconfig"

#define NET_STAT_INFO  "/proc/net/dev"
#define WIRE_LESS_INFO "/proc/net/wireless"
#define NETWORK_INFO   "/opt/nagios/cfg/network.cfg"

#define TAG_SSID        "ESSID"
#define TAG_ETH1        "eth1"


double wValue[2] = {0.0,0.0};
double cValue[2] = {0.0,0.0};
const char *pragrom = "check_network";


NETWORK_INFO_t tNetworkInfo[2]; //0:etho 1:eth1
int socketfd = 0;

static int get_old_netinfo(); //获取上次输入数据
static int flush_netinfo();//将最新数据写入文件
static int init();
static int reinit();
static int get_net_status(char index); //获取网卡状态 0：down 1：up
static int get_wireless_eth();//获取wireless使用的网卡
static int find_eth();//系统使用网卡
static int get_wireless_info();//获取wire信号强度
static int network_info();//获取网卡信息 输入输出数据
static int get_network_info();
static void print_help();
static void print_usage();

static int 
get_old_netinfo(){
	
	char line[MIN_DATA_LEN+1];
	FILE *fp = NULL;
	if(!(fp = fopen(NETWORK_INFO,"r"))){
		return OK;
	}
	
	memset(line,0,sizeof line);
	while(fgets(line,MIN_DATA_LEN,fp)){
		
		if(!strncmp(line,"eth0:",strlen("eth0:"))){	
			if(EOF == sscanf(line,"%*s %lu %llu",&(tNetworkInfo[0].dw_total_tick),&(tNetworkInfo[0].dw_total_io))){
				tNetworkInfo[0].dw_total_tick = 0;
				tNetworkInfo[0].dw_total_io = 0;
				break;
			}
		}
		else if(!strncmp(line,"eth1:",strlen("eth1:"))){
			if(EOF == sscanf(line,"%*s %lu %llu",&(tNetworkInfo[1].dw_total_tick),&(tNetworkInfo[1].dw_total_io))){
				tNetworkInfo[1].dw_total_tick = 0;
				tNetworkInfo[1].dw_total_io = 0;
				break;
			}
		}
		memset(line,0,sizeof line);
	}

	fclose(fp);
	return OK;
}

static int 
flush_netinfo(){
		
	FILE *fp = NULL;

	if(!(fp = fopen(NETWORK_INFO,"w"))){
		printf("open file:%s for write error\n",NETWORK_INFO);
		return ERROR;
	}
	
	fprintf(fp,"eth0: %lu %llu\n",tNetworkInfo[0].dw_total_tick,tNetworkInfo[0].dw_total_io);
	fprintf(fp,"eth1: %lu %llu\n",tNetworkInfo[1].dw_total_tick,tNetworkInfo[1].dw_total_io);

	fclose(fp);
	return OK;
}

static int 
init(){
	if((socketfd = socket(AF_INET,SOCK_STREAM,0) )<= 0){
		socketfd = 0;
		return ERROR;
	}

	get_old_netinfo();

	return OK;
}

static int
reinit(){
	if(socketfd != 0)
		close(socketfd);
	socketfd = 0;

	return flush_netinfo();
}

static int 
get_wireless_eth(){

	int result = OK;
	FILE *fp = NULL;
	char line[MIN_DATA_LEN+1];

	if(!(fp = fopen(WIRE_LESS_INFO,"r"))){
		printf("exec cmd %s error\n",CMD_IWCONFIG);
		return ERROR;
	}
	
	memset(line,0,sizeof line);
	while(fgets(line,MIN_DATA_LEN,fp)){
		
		if(strstr(line,DEV_ETH0)){
			tNetworkInfo[0].bwifi = 1;
		}
		else if(strstr(line,DEV_ETH1)){
			tNetworkInfo[1].bwifi = 1;
		}
		
		memset(line,0,sizeof line);
	}
	
	fclose(fp);
	return result;
}

static int 
find_eth(){

	int result = OK;
	struct ifaddrs *ifap = NULL,*ifa=NULL;

	if(-1 == getifaddrs(&ifap)){
		printf("get if addr error\n");
		return ERROR;
	}

	for(ifa = ifap;ifa;ifa = ifa->ifa_next){
		if(!strcmp(ifa->ifa_name,DEV_ETH0)&& INDEX_ETH0 != tNetworkInfo[0].cindex){
			tNetworkInfo[0].cindex = INDEX_ETH0;
			get_net_status(INDEX_ETH0);
		}
		else if(!strcmp(ifa->ifa_name,DEV_ETH1)&& INDEX_ETH1 != tNetworkInfo[1].cindex){
			tNetworkInfo[1].cindex = INDEX_ETH1;
			get_net_status(INDEX_ETH1);
		}
	}

	freeifaddrs(ifap);
	return result;
}

static int 
get_net_status(char index){
	int result = OK;
	const char* pDevName = NULL;
	if(INDEX_ETH0 == index) pDevName = DEV_ETH0;
	else if(INDEX_ETH1 == index) pDevName = DEV_ETH1;
	
	if(0 == socketfd){
		return ERROR;
	}

	struct ifreq ifr;
	memset(&ifr, 0, sizeof(ifreq));
	memcpy(ifr.ifr_name, pDevName, strlen((const char*)pDevName) );

	//up or down;
	if( ioctl(socketfd, SIOCGIFFLAGS, &ifr ) == -1 ) {
			return ERROR;
	} 
	tNetworkInfo[index-1].status = (ifr.ifr_flags) & IFF_RUNNING ?1:0;
	
	return result;	
}

static int 
network_info(){
	int result = OK;
	FILE *fp = NULL;
	char line[MIN_DATA_LEN+1] = {0};
	TIC_t nouse = 0,irecv = 0,iwrite = 0;
	char *ptr = NULL;

	if(!(fp = fopen(NET_STAT_INFO,"r"))){
		printf("open net stat file:%s error\n",NET_STAT_INFO);
		return ERROR;	
	}

	memset(line,0,sizeof line);
	while(fgets(line,MIN_DATA_LEN,fp)){
		
		if((ptr = strstr(line,"eth0:"))){
			ptr += strlen("eth0:");
			while(*ptr && *ptr==' ')
				ptr++;
			
			//printf("eth0:info:%s\n",ptr);
			if(EOF == sscanf(ptr,"%llu %llu %llu %llu %llu %llu %llu %llu %llu",&irecv,&nouse,&nouse,&nouse,&nouse,&nouse,&nouse,&nouse,&iwrite)){
				result = ERROR;
				break;
			}	
			//printf("eth0::irecv::%llu iwrite::%llu totol::%llu\n",irecv,iwrite,tNetworkInfo[0].dw_total_io);
			if(irecv + iwrite < tNetworkInfo[0].dw_total_io)
				tNetworkInfo[0].dw_total_io = 0;
			tNetworkInfo[0].dw_ex_io = irecv + iwrite - tNetworkInfo[0].dw_total_io;
			tNetworkInfo[0].dw_total_io = irecv + iwrite;	
		}
		else if((ptr = strstr(line,"eth1:"))){
			ptr += strlen("eth1:");
			while(*ptr && *ptr==' ')
				ptr++;

			//printf("eth1:info:%s\n",ptr);
			if(EOF == sscanf(ptr,"%llu %llu %llu %llu %llu %llu %llu %llu %llu",&irecv,&nouse,&nouse,&nouse,&nouse,&nouse,&nouse,&nouse,&iwrite)){
				result = ERROR;
				break;
			}
			//printf("eth1::irecv::%llu iwrite::%llu totol::%llu\n",irecv,iwrite,tNetworkInfo[1].dw_total_io);
			if(irecv + iwrite < tNetworkInfo[1].dw_total_io)
				tNetworkInfo[1].dw_total_io = 0;
			tNetworkInfo[1].dw_ex_io = irecv + iwrite - tNetworkInfo[1].dw_total_io;
			tNetworkInfo[1].dw_total_io = irecv + iwrite;
		}
		
		memset(line,0,sizeof line);
	}

	fclose(fp);
	return result;
}

static int 
get_network_info(){

	unsigned long dwtick = 0,dwtotaltick = 0;
	struct timeval tv = {0};
	gettimeofday(&tv,NULL);
	dwtotaltick = tv.tv_sec;

	dwtick = dwtotaltick-(tNetworkInfo[0].dw_total_tick?tNetworkInfo[0].dw_total_tick:tNetworkInfo[1].dw_total_tick);
	
	if(ERROR == network_info()){
		return ERROR;
	}

	if(INDEX_ETH0 == tNetworkInfo[0].cindex){
		
		tNetworkInfo[0].dw_tick = dwtick;
		tNetworkInfo[0].dw_total_tick = dwtotaltick;
	}
	if(INDEX_ETH1 == tNetworkInfo[1].cindex){
		
		tNetworkInfo[1].dw_tick = dwtick;
		tNetworkInfo[0].dw_total_tick = dwtotaltick;
	}

	return OK;
}

static int 
get_wireless_info(){
	
	int result = OK;
	FILE *fp = NULL;
	char* pDevName = NULL;
	char line[MIN_DATA_LEN+1] = {0};
	int norse=0;
	char index = 0;

	if(tNetworkInfo[0].bwifi){
		if(INDEX_ETH0 == tNetworkInfo[0].cindex){
			pDevName = (char*)DEV_ETH0;
		}
		else
			return OK;
	}
	else if(tNetworkInfo[1].bwifi){
		if(INDEX_ETH1 == tNetworkInfo[1].cindex){
			pDevName = (char*)DEV_ETH1;
			index = 1;
		}
		else
			return OK;
	}
	else
	{
		return OK;
	}

	if(!(fp = fopen(WIRE_LESS_INFO,"r"))){
		printf("open file:%s error\n",WIRE_LESS_INFO);
		return ERROR;
	}

	memset(line,0,sizeof line);

	while(fgets(line,MIN_DATA_LEN,fp)){
		if(strstr(line,pDevName)){
			char *ptr = line;
			while(*ptr==' '|| *ptr == '\t')
				ptr++;

			if(EOF == sscanf(ptr,"%*s %d %d. %d",&norse,&norse,&tNetworkInfo[index].levels)){
				result = ERROR;
				break;
			}	
		}
	}


	fclose(fp);
	return result;
}

static void 
get_value(char *arg,double *th)
{
	size_t i = 0,n = 0;
	char *str = arg,*p = NULL;

	n = strlen(arg);
	for(;i < 2;i++){
		th[i] = strtod(str,&p);
		if(p == str)
			break;


		str = p+1;
		if(n <= (size_t)(str-arg))
			break;
	}
}

static int 
process_arguments(int argc,char *argv[])
{
	int c = 0;

	int options = 0;
	static struct option longopts[] = {
		{"warning",required_argument,0,'w'},
		{"critical",required_argument,0,'c'},
		{"help",required_argument,0,'h'},
		{0,0,0,0}
	};

	if(argc < 2)
		return ERROR;

	while(1)
	{
		c = getopt_long(argc,argv,"w:c:h",longopts,&options);
		if(-1 == c || EOF == c)
			break;

		switch(c)
		{
		case 'w':
			get_value(optarg,wValue);
			break;
		case 'c':
			get_value(optarg,cValue);
			break;
		case 'h':
			print_help();
			exit(STATE_OK);
		default:
			break;
		}
	}

	return OK;
}

int 
main(int argc,char *argv[]){
	int result = STATE_OK,i = 0;
	char stat_line[MIN_DATA_LEN+1] = {0};
	double speed = 0;
	unsigned long dwtick = 0;
	int levels = 0;

	// 字符集编码方式
	setlocale(LC_ALL,"");
	setlocale(LC_NUMERIC,"POSIX");//小数点定义以posix

	memset(&tNetworkInfo,0,sizeof tNetworkInfo);

	if(ERROR == process_arguments(argc,argv)){
		printf("invaliad parameter about program:%s\n",pragrom);
		return STATE_UNKNOWN;
	}

	if(ERROR == init()){
		printf("error init about program:%s\n",pragrom);
		result = STATE_UNKNOWN;
		goto END;
	}

	
	if(ERROR == get_wireless_eth()){
		printf("error get wire eth about program:%s\n",pragrom);
		result = STATE_UNKNOWN;
		goto END;
	}

	if(ERROR == find_eth()){
		printf("error find eth about program:%s\n",pragrom);
		result = STATE_UNKNOWN;
		goto END;
	}

	if(ERROR == get_network_info()){
		printf("error get network info program:%s\n",pragrom);
		result = STATE_UNKNOWN;
		goto END;
	}

	if(ERROR == get_wireless_info()){
		printf("error get wireless info about program:%s\n",pragrom);
		result = STATE_UNKNOWN;
		goto END;
	}

	dwtick = tNetworkInfo[0].dw_tick?tNetworkInfo[0].dw_tick:tNetworkInfo[1].dw_tick;
	if(dwtick <= 0)
		dwtick = 60;
	//printf("dwtick is %lu exio:%lf\n",dwtick,(double)(tNetworkInfo[0].dw_ex_io+tNetworkInfo[1].dw_ex_io));
	speed = (double)(tNetworkInfo[0].dw_ex_io + tNetworkInfo[1].dw_ex_io)/(dwtick);

	if(speed > wValue[0]){
		result = STATE_WARNING;
		if(speed > cValue[0]){
			result = STATE_CRITICAL;
		}
	}

	if(tNetworkInfo[0].bwifi && tNetworkInfo[0].status){
		//printf("wifi levels::%d\n",tNetworkInfo[0].levels);
		levels = tNetworkInfo[0].levels;
	}
	else if(tNetworkInfo[1].bwifi && tNetworkInfo[1].status){
		//printf("wifi levels::%d\n",tNetworkInfo[1].levels);
		levels = tNetworkInfo[1].levels;
	}
	else{
		//printf("not use wifi\n");
		levels = 0;
	}

	snprintf(stat_line,sizeof stat_line,"net info speed:%.2f(b/s) levels:%d",speed,levels);

	printf("%s-%s\n",state_text(result),stat_line);
	printf("eth0:status %d iswifi %d\n",tNetworkInfo[0].status,tNetworkInfo[0].bwifi);
	printf("eth1:status %d iswifi %d\n",tNetworkInfo[1].status,tNetworkInfo[1].bwifi);

	if(tNetworkInfo[0].bwifi && tNetworkInfo[0].status){
		printf("wifi levels::%d\n",tNetworkInfo[0].levels);
	}
	else if(tNetworkInfo[1].bwifi && tNetworkInfo[1].status){
		printf("wifi levels::%d\n",tNetworkInfo[1].levels);
	}
	else{
		printf("not use wifi\n");
	}
	putchar('|');

	printf("load=%.2lf;%.2lf;%.2lf levels=%d;",speed,wValue[0],cValue[0],levels);

END:
	if(ERROR == reinit()){
		printf("erro reinit about program:%s\n",pragrom);
		result = STATE_UNKNOWN;
	}
	return result;
}

static void 
print_help(){

	printf ("%s\n", "This plugin checks the status of net card");
	printf ("\n\n");

	print_usage();

	printf (" %s\n", "-w, --warning=PERCENT%");
	printf ("    %s\n", "Exit with WARNING status if less than PERCENT speed of net card ");
	printf (" %s\n", "-c, --critical=PERCENT%");
	printf ("    %s\n", "Exit with CRITICAL status if less than PERCENT speed of net card");

}

static void
print_usage(void)
{
	printf ("%s\n", "WARNING: check_network");
	printf ("%s\n", "Usage:");
	printf(" %s  [-w <warn>] [-c <crit>] [-h <help>]\n", pragrom);
}



#include "common.h"

const char * 
state_text(int result)
{
	switch (result)
	{
	case STATE_OK:
		return "OK";
	case STATE_WARNING:
		return "WARNING";
	case STATE_CRITICAL:
		return "CRITICAL";
	case STATE_DEPENDENT:
		return "DEPENDENT";
	case ERROR:
		return "ERROR";
	default:
		return "UNKNOWN";
	}
}

int 
strpos(const char *haystack,const char *needle)    
{    
	if(!haystack || !needle)
		return -1;
	
	register unsigned char c, needc;  
	unsigned char const *from, *end; 
	int i = 0;
	int len = strlen(haystack);  
	int needlen = strlen(needle);  
	from = (unsigned char *)haystack;  
	end = (unsigned char *)haystack + len;  
	const char *findreset = needle;  
	for (i = 0; from < end; ++i) {  
		c = *from++;  
		needc = *needle;  
		if(c == needc) {  
			++needle;  
			if(*needle == '\0') {  
				if (len == needlen)   
					return 0;  
				else  
					return i - needlen+1;  
			}  
		}    
		else {    
			if(*needle == '\0' && needlen > 0)  
				return i - needlen +1;  
			needle = findreset;    
		}  
	}    
	return  -1;    
}    
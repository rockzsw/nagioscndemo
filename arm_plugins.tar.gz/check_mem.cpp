
#include "common.h"

double wValue[1] = {0.0};
double cValue[1] = {0.0};


#define  MEM_PROC_PATH     "/proc/meminfo"
#define  MEM_TOTAL         "MemTotal:"
#define  MEM_FREE          "MemFree:"
#define  MEM_BUFFER        "Buffers:"
#define  MEM_CACHE         "Cached:"

TIC_t total_mem = 0,free_mem = 0,buffer_mem = 0,cache_mem = 0;
const char *pragrom = "check_mem";

static int get_mem_info();
static void print_help();
static void print_usage();

static int 
get_mem_info(){
	int result = OK;
	FILE *fp = NULL;
	char line[MIN_DATA_LEN+1];

	if(!(fp = fopen(MEM_PROC_PATH,"r"))){
		printf("open mem info:%s error\n",MEM_PROC_PATH);
		return ERROR;
	}
	
	memset(line,0,sizeof line);
	while(fgets(line,MIN_DATA_LEN,fp)){
		if(strstr(line,MEM_TOTAL)){
			if(EOF == sscanf(line,"MemTotal:%llu",&total_mem)){
				result = ERROR;
				break;
			}
		}
		else if(strstr(line,MEM_FREE)){
			if(EOF == sscanf(line,"MemFree:%llu",&free_mem)){
				result = ERROR;
				break;
			}

		}
		else if(strstr(line,MEM_BUFFER)){
			if(EOF == sscanf(line,"Buffers:%llu",&buffer_mem)){
				result = ERROR;
				break;
			}
		}
		else if(strstr(line,MEM_CACHE)){
			if(EOF == sscanf(line,"Cached:%llu",&cache_mem)){
				result = ERROR;
				break;
			}
			break;
		}
	}

	fclose(fp);
	return result;
}

static void 
get_value(char *arg,double *th)
{
	size_t i = 0,n = 0;
	char *str = arg,*p = NULL;

	n = strlen(arg);
	for(;i < 3;i++){
		th[i] = strtod(str,&p);
		if(p == str)
			break;

		str = p+1;
		if(n <= (size_t)(str-arg))
			break;
	}
}

static int 
process_arguments(int argc,char *argv[])
{
	int c = 0;

	int options = 0;
	static struct option longopts[] = {
		{"warning",required_argument,0,'w'},
		{"critical",required_argument,0,'c'},
		{"help",required_argument,0,'h'},
		{0,0,0,0}
	};

	if(argc < 2)
		return ERROR;

	while(1)
	{
		c = getopt_long(argc,argv,"w:c:h",longopts,&options);
		if(-1 == c || EOF == c)
			break;

		switch(c)
		{
		case 'w':
			get_value(optarg,wValue);
			break;
		case 'c':
			get_value(optarg,cValue);
			break;
		case 'h':
			print_help();
			exit(STATE_OK);
		default:
			break;
		}
	}

	return OK;
}

int 
main(int argc,char *argv[]){

	int result = STATE_OK;
	char stat_line[MIN_DATA_LEN+1] = {0};
	double meminfo = 0.0;


	if(ERROR == process_arguments(argc,argv)){
		printf("invaliad parameter about program:%s\n",pragrom);
		result = STATE_UNKNOWN;
		goto END;
	}

	if(ERROR == get_mem_info()){
		printf("get mem info failed \n");
		result = STATE_UNKNOWN;
		goto END;
	}

	meminfo =1- (double)(free_mem + buffer_mem + cache_mem)/(double)(total_mem);

	if(meminfo > wValue[0]){
		result = STATE_WARNING;
		if(meminfo > cValue[0]){
			result = STATE_CRITICAL;
		}
	}

	snprintf(stat_line,sizeof stat_line,"mem info:%.2f",meminfo);

	printf("%s-%s\n",state_text(result),stat_line);
	printf("mem info--total:%llu(KB) free:%llu(KB)|",total_mem,free_mem+buffer_mem+cache_mem);
	printf("load:mem:%.2lf wValue:%.2lf cValue:%.2lf",meminfo,wValue[0],cValue[0]);
END:
	return result;
}

static void 
print_help(){

	printf ("%s\n", "This plugin checks the status of mem");
	printf ("\n\n");

	print_usage();

	printf (" %s\n", "-w, --warning=PERCENT%");
	printf ("    %s\n", "Exit with WARNING status if less than PERCENT of mem");
	printf (" %s\n", "-c, --critical=PERCENT%");
	printf ("    %s\n", "Exit with CRITICAL status if less than PERCENT of mem");

}

static void
print_usage(void)
{
	printf ("%s\n", "WARNING: check_mem");
	printf ("%s\n", "Usage:");
	printf(" %s  [-w <warn>] [-c <crit>] [-h <help>]\n", pragrom);
}
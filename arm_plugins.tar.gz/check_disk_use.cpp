/*

	check_disk_use

*/

#include "common.h"


#define CMD_IO_STAT          "iostat -k"
#define CMD_DISK_MOUNT       "mount"
#define CMD_DISK_INFO        "df -k"

#define TAG_IO_CPU           "avg-cpu:"
#define TAG_ON               "on"
#define TAG_DEV              "/dev"	
#define TAG_ROOT             "root"
#define TAG_SPACE            " "
#define TAG_TAG              "/"

const char *mount_dir = "/mnt/sd";
const char *pragrom = "check_disk";

DISK_INFO_t tDiskInfo[2]; //������Ϣ flash��sd
char mount_num = 0;
double u = 0.0,s = 0.0; //�û�cpu��ϵͳcpu
double rspeed=0.0,wspeed = 0.0;
unsigned long long readtotal = 0,writetotal=0; //����д�ٶ� �ܹ���д
double wValue[2] = {0.0,0.0};//flash �� sd ʹ������ֵ
double cValue[2] = {0.0,0.0};


static char is_disk_exist(const char*diskname);//-1:��ʾû�г��� ������ʾ�ڼ���
static int  get_io_stat();//��ȡ����״̬
static int  get_mount_info();//��ȡ���ش�����Ϣ
static int  get_disk_info();//����ʹ�����
static char is_disk_exist(const char*diskname);//���ش����Ƿ����
static void print_help();
static void print_usage();


static int 
get_io_stat(){
	int result = OK;
	FILE *fp =  NULL;
	char line[MIN_DATA_LEN+1];
	double n=0,iowait=0,steal=0,idle=0;
	double nose = 0;
		
	if(!(fp = popen(CMD_IO_STAT,"r"))){
		printf("popen %s error\n",CMD_IO_STAT);
		return ERROR;
	}
	
	memset(line,0,sizeof line);
	while(fgets(line,MIN_DATA_LEN,fp)){
		if(!strncmp(line,TAG_IO_CPU,strlen(TAG_IO_CPU))){
			memset(line,0,sizeof line);
			if(fgets(line,MIN_DATA_LEN,fp)){
				if(EOF == sscanf(line,"%lf %lf %lf %lf %lf",&u,&n,&s,&iowait,&steal,&idle)){
					result = ERROR;
					break;
				}
			}
		}
		else if(!strncmp(line,tDiskInfo[1].disk_name+strlen("/dev/"),strlen(tDiskInfo[1].disk_name)-strlen("/dev/"))){
			if(EOF == sscanf(line,"%*s %lf %lf %lf %llu %llu",&nose,&rspeed,&wspeed,&readtotal,&writetotal)){
				result = ERROR;
				break;
			}
		}
		memset(line,0,sizeof line);
	}
	
	pclose(fp);
	return result;
}

static int
get_mount_info(){
	int result = OK;
	FILE *fp = NULL;
	char line[MIN_DATA_LEN+1];
	int i = 1;
	int pos = 0,tmppos = 0;
	char *ptr = NULL;

	if(!(fp = popen(CMD_DISK_MOUNT,"r"))){
		printf("popen %s error\n",CMD_DISK_MOUNT);
		return ERROR;
	}

	memset(line,0,sizeof line);
	while(fgets(line,MIN_DATA_LEN,fp)){
		if(!strncmp(line,TAG_DEV,strlen(TAG_DEV))&&strstr(line,TAG_ON)){
			if(strstr(line,TAG_ROOT)){
				pos = strpos(line,TAG_SPACE);
				memcpy(tDiskInfo[0].disk_name,line,pos);
				ptr = line+pos;
				pos = strpos(ptr,TAG_TAG);
				tmppos = strpos(ptr+pos,TAG_SPACE);

				if(-1 == pos || -1 == tmppos){
					result = ERROR;
					break;
				}
				memcpy(tDiskInfo[0].mount_path,ptr+pos,tmppos);
			}
			else{
				pos = strpos(line,TAG_SPACE);
				memcpy(tDiskInfo[i].disk_name,line,pos);
				ptr = line + pos;
				pos = strpos(ptr,TAG_TAG);
				tmppos = strpos(ptr+pos,TAG_SPACE);

				if(-1 == pos || -1 == tmppos){
					result = ERROR;
					break;
				}
				memcpy(tDiskInfo[i].mount_path,ptr+pos,tmppos);
				i++;	
			}
			if(i >= 2)
				break;
		
		}
		memset(line,0,sizeof line);
	}
	mount_num = i;

	pclose(fp);
	return result;
}


static int
get_disk_info(){
	int result = OK;
	FILE *fp = NULL;
	char line[MIN_DATA_LEN+1];
	int i = 0;
	int pos = 0,tmppos = 0;
	char *prt = NULL;

	if(!(fp = popen(CMD_DISK_INFO,"r"))){
		printf("popen %s error\n",CMD_DISK_INFO);
		return ERROR;
	}

	memset(line,0,sizeof line);
	while(fgets(line,MIN_DATA_LEN,fp)){
		
		if((i = is_disk_exist(line)) != -1){
			if(EOF == sscanf(line,"%*s %llu %llu",&tDiskInfo[i].total,&tDiskInfo[i].used)){
				printf("sscanf error\n");
				result = ERROR;
				break;
			}
		}
		
		memset(line,0,sizeof line);
	}

	pclose(fp);
	return result;

}

static char 
is_disk_exist(const char*diskname){
	int i = 0;
	for(;i<mount_num;i++){
		if(strstr(diskname,tDiskInfo[i].disk_name)){
			return i;
		}
	}

	return -1;
}

static void 
get_value(char *arg,double *th)
{
	size_t i = 0,n = 0;
	char *str = arg,*p = NULL;

	n = strlen(arg);
	for(;i < 3;i++){
		th[i] = strtod(str,&p);
		if(p == str)
			break;

		str = p+1;
		if(n <= (size_t)(str-arg))
			break;
	}
}

static int 
process_arguments(int argc,char *argv[])
{
	int c = 0;

	int options = 0;
	static struct option longopts[] = {
		{"warning",required_argument,0,'w'},
		{"critical",required_argument,0,'c'},
		{"help",required_argument,0,'h'},
		{0,0,0,0}
	};

	if(argc < 2)
		return ERROR;

	while(1){
		c = getopt_long(argc,argv,"w:c:h",longopts,&options);
		if(-1 == c || EOF == c)
			break;

		switch(c)
		{
		case 'w':
			get_value(optarg,wValue);
			break;
		case 'c':
			get_value(optarg,cValue);
			break;
		case 'h':
			print_help();
			exit(STATE_OK);
		default:
			break;
		}
	}

	return OK;
}


int 
main(int argc,char *argv[]){
	int result = STATE_OK;
	char stat_line[MIN_DATA_LEN+1] = {0};
	char line[MIN_DATA_LEN+1] = {0};
	double root_used=0.0,sd_used = 0.0;


	if(ERROR == process_arguments(argc,argv)){
		printf("invaliad parameter about program:%s\n",pragrom);
		result = STATE_UNKNOWN;
		goto END;
	}

	if(ERROR == get_mount_info()){
		result = STATE_UNKNOWN;
		goto END;
	}

	if(ERROR == get_disk_info()){
		result = STATE_UNKNOWN;
		goto END;
	}

	if(ERROR == get_io_stat()){
		result = STATE_UNKNOWN;
		goto END;
	}

	if(2 == mount_num){
		if(strncmp(tDiskInfo[1].mount_path,mount_dir,strlen(mount_dir))){
			result = STATE_WARNING;
			printf("%s:mount dir error:%s::%s\n",state_text(result),tDiskInfo[1].disk_name,tDiskInfo[1].mount_path);
			goto END;
		}
	}
	else{
		result = STATE_WARNING;
		printf("%s:is not mount:%s\n",state_text(result),mount_dir);
		goto END;
	}

	//ֵ
	root_used = (double)(tDiskInfo[0].used)/(double)(tDiskInfo[0].total);
	sd_used = (double)(tDiskInfo[1].used)/(double)(tDiskInfo[1].total);
	if(root_used > wValue[0] || sd_used > wValue[1]){
		result = STATE_WARNING;
		if(root_used > cValue[0] || sd_used > cValue[1]){
			result = STATE_CRITICAL;
		}
	}

	snprintf(stat_line,sizeof stat_line,"disk info:%.2f %.2f",root_used,sd_used);
	printf("%s-%s\n",state_text(result),stat_line);
	
	printf("io cpu ::%.2f%% %.2f%%\n",u,s);
	printf("disk %s:%.2f(kb/s) %.2f(kb/s) %llu(kb) %llu(kb)\n",tDiskInfo[1].mount_path,rspeed,wspeed,readtotal,writetotal);
	printf("root disk size:%llu(M) %llu(M)\n",tDiskInfo[0].used/1024,tDiskInfo[0].total/1024);
	printf("mount disk size:%llu(M) %llu(M)\n",tDiskInfo[1].used/1024,tDiskInfo[1].total/1024);
	putchar('|');
	printf("load--ruse:%.2lf sduse:%.2lf wValue:%.2lf %.2lf cValue:%.2lf %.2lf",root_used,sd_used,wValue[0],wValue[1],cValue[0],cValue[1]);
END:
	return result;
}

static void 
print_help(){

	printf ("%s\n", "This plugin checks the status of disk and io");
	printf ("\n\n");

	print_usage();

	printf (" %s\n", "-w, --warning=PERCENT%");
	printf ("    %s\n", "Exit with WARNING status if less than PERCENT of disk");
	printf (" %s\n", "-c, --critical=PERCENT%");
	printf ("    %s\n", "Exit with CRITICAL status if less than PERCENT of disk");

}

static void
print_usage(void)
{
	printf ("%s\n", "WARNING: check_disk");
	printf ("%s\n", "Usage:");
	printf(" %s  [-w <warn>] [-c <crit>] [-h <help>]\n", pragrom);
}
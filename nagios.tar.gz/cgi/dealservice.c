
#include "../include/config.h"
#include "../include/common.h"
#include "../include/objects.h"
#include "../include/macros.h"
#include "../include/cgiutils.h"
#include "../include/cgiauth.h"
#include "../include/getcgi.h"
#include "../xdata/xconfiguationdeal.h"

#define NORMAL_HOST           "normal_host"
#define NORMAL_TIMEPRIOD      "normal_timepriod"
#define NORMAL_TIME_PRIOD     "24x7"

enum{
	SERVER_MODIFY,
	SERVER_MODIFY_EX,
	SERVER_ADD,
	SERVER_DELETE
};

enum{
	METHOD_GET,
	METHOD_POST
};

enum{
	DISPLAY_ADD,
	DISPLAY_DELETE,
	DISPLAY_MODIFY
};

extern char   url_images_path[MAX_FILENAME_LENGTH];
extern char   url_logo_images_path[MAX_FILENAME_LENGTH];
extern char   url_stylesheets_path[MAX_FILENAME_LENGTH];
extern char   main_config_file[MAX_FILENAME_LENGTH];



unsigned char method_type = METHOD_GET;
unsigned char display_type = DISPLAY_ADD;
unsigned int id = 0;
char *command_line = NULL;
char *command_arguments = NULL;
char *time_priod = NULL;
char *host_name = NULL;

authdata current_authdata;

void document_header(int);
void document_footer(void);
int process_cgivars(void);
void dealservice_init();

void display_operation_service(unsigned char type);
void display_service_info(void);
void deal_fail_info(const char *info);

int main(void)
{
	
	reset_cgi_vars();
	dealservice_init();

	process_cgivars();
	//printf("Content-type:text/html\n\n");
	//printf("method_type:%d display_typ:%d\n",method_type,display_type);

	//对应不同的显示类型进行不同操作
	if(METHOD_POST == method_type){
		int result = ERROR;
		//add
		if(DISPLAY_ADD == display_type){
			result = xconfiguation_add_service_data(command_arguments,host_name,command_line,strtok(time_priod,"("));
			if(ERROR == result){
				document_header(FALSE);
				deal_fail_info("add service");
				document_footer();
				goto END;	
			}
		}
		//delete
		else if(DISPLAY_DELETE == display_type){
			result = xconfiguation_delete_service_data(id);
			if(ERROR == result){
				document_header(FALSE);
				deal_fail_info("delete service");
				document_footer();
				goto END;
			}
		}
		//modify
		else if(DISPLAY_MODIFY == display_type){
			result = xconfiguation_modify_service_data(id,command_line,time_priod);
			if(ERROR == result){
				document_header(FALSE);
				deal_fail_info("modify service");
				document_footer();
				goto END;
			}
		}
		xconfiguation_write_service_config_data();
		xconfiguation_clear_memory();

		result = xconfiguation_init_config_data();
		if(ERROR == result){
			document_header(FALSE);
			cgi_config_file_error(get_cgi_config_location());
			document_footer();
			goto END;
		}
	}

	document_header(TRUE);
	
	
	get_authentication_information(&current_authdata);

	printf("<table border=0 width=100%%>\n");
	printf("<tr>\n");

	printf("<td align=left valign=top width=50%%>\n");
	display_info_table("服务信息", FALSE,&current_authdata);
	printf("</td>\n");

	printf("</tr>\n");
	printf("</table>\n");
	
	//
	display_operation_service(SERVER_ADD);

	//
	display_service_info();
	//
	xconfiguation_clear_memory();
	//
	document_footer();

END:
	my_free(command_line);
	my_free(command_arguments);
	my_free(time_priod);
	my_free(host_name);
	return OK;
}

void display_service_info(){
	printf("<p><div align=center margin-top=30px class='datatitle'>服务信息</div></p>\n");
	printf("<p><div align=center>\n");
	printf("<form id='form_info' method='post' action='../cgi-bin/dealservice.cgi'>\n");
	printf("<table border=0 class='data' id='service_info'>\n");
	
	printf("<tr>\n");
	printf("<th class='data'>ID</th>\n");
	printf("<th class='data'>主机</th>\n");
	printf("<th class='data'>服务</th>\n");
	printf("<th class='data'>执行命令</th>\n");
	printf("<th class='data'>执行时间段</th>\n");
	printf("<th class='data'>操作</th>\n");
	printf("</tr>\n");

	//service
	configuation_service *service_head = xconfiguation_get_service_data();

	//
	configuation_timeperiod *timeperiod_head = xconfiguation_get_timperiod_data();
	configuation_timeperiod *timeperiod_tmp = timeperiod_head;
	//
	
	for(;service_head;service_head = service_head->next){
		printf("<tr>\n");
		printf("<td><input type='text' name='service_id' value='%d'size=4 readonly/></td>\n",service_head->id);
		printf("<td ><input type='text' name='host_name' value='%s' readonly /></td>\n",service_head->host_name?service_head->host_name:"");
		printf("<td ><input type='text' name='service_description' value='%s' readonly/></td>\n",service_head->service_description?service_head->service_description:"");
		printf("<td><input type='text' name='command' size=100 value='%s'></td>\n",service_head->check_command?service_head->check_command:"");
		//printf("<td>%s</td>\n",service_head->check_command?service_head->check_command:"");
		//printf("<td>%s</td>\n",service_head->check_period?service_head->check_period:NORMAL_TIME_PRIOD);
		printf("<td>\n");
		printf("<select name='timepriod'>\n");
		for(;timeperiod_head;timeperiod_head = timeperiod_head->next){
			
			if(service_head->check_period){
				if(!strcmp(timeperiod_head->timeperiod_name,service_head->check_period))
					printf("<option selected>%s</option>\n",timeperiod_head->timeperiod_name?timeperiod_head->timeperiod_name:NORMAL_TIMEPRIOD);
				else
					printf("<option>%s</option>\n",timeperiod_head->timeperiod_name?timeperiod_head->timeperiod_name:NORMAL_TIMEPRIOD);
			}
			else
			{
				if(!strcmp(timeperiod_head->timeperiod_name,NORMAL_TIME_PRIOD))
					printf("<option selected>%s</option>\n",timeperiod_head->timeperiod_name?timeperiod_head->timeperiod_name:NORMAL_TIMEPRIOD);
				else
					printf("<option>%s</option>\n",timeperiod_head->timeperiod_name?timeperiod_head->timeperiod_name:NORMAL_TIMEPRIOD);
			}	
				
		}
		printf("</select>\n");
		printf("</td>\n");

		printf("<td>\n");
		printf("<input type='button' name='modify' onclick='modifyservice(this)' value='修改'></input>\n");
		printf("<input type='button' name='delete' onclick='deleteservice(this)' value='删除'></input>\n");
		printf("</td>\n");	
		printf("</tr>\n");
		timeperiod_head = timeperiod_tmp;
	}

	
	printf("</table>\n");
	printf("</form>\n");
	printf("</div></p>\n");

}

void display_operation_service(unsigned char type){

	printf("<p><div align=center class='datatitle'>添加服务</div></p>\n");
	printf("<p><div align=center>\n");
	printf("<form action='%s' method='post' id='form_service' onsubmit='return check()'>\n","dealservice.cgi");
	printf("<table border=0 class='data'>\n");

	printf("<tr>\n");
	printf("<th class='data'>添加信息</th>\n");
	printf("<th class='data'>添加内容</th>\n");
	printf("</tr>\n");

	//host
	configuation_host *host_head = xconfiguation_get_host_data();
	//
	printf("<tr>\n");
	printf("<td>主机:</td>\n");
	printf("<td>\n");
	printf("<select name='host_name'>\n");
	//printf("<option selected>linux_service</option>\n");
	//printf("<option>test1</option>\n");
	for(;host_head;host_head = host_head->next){
		printf("<option>%s</option>\n",(host_head->host_name)?host_head->host_name:NORMAL_HOST);
	}
	printf("</select>\n");
	printf("</td>\n");
	printf("</tr>\n");

	//timepriod
	configuation_timeperiod *timeperiod_head = xconfiguation_get_timperiod_data();
	//
	printf("<tr>\n");
	printf("<td>允许检查时间:</td>\n");
	printf("<td>\n");
	printf("<select name='timepriod'>\n");
	//printf("<option>1x7(1 Hours A Day, 7 Days A Week)</option>\n");
	//printf("<option>tarhour(1 Hours A week)</option>\n");
	//printf("<option>24x7(24 Hours A Day, 7 Days A Week)</option>\n");
	for(;timeperiod_head;timeperiod_head = timeperiod_head->next){
		printf("<option>%s(%s)</option>\n",timeperiod_head->timeperiod_name?timeperiod_head->timeperiod_name:NORMAL_TIMEPRIOD,timeperiod_head->alias?timeperiod_head->alias:NORMAL_TIMEPRIOD);
	}
	printf("</select>\n");
	printf("</td\n>");
	printf("</tr>\n");

	//commond
	printf("<tr>\n");
	printf("<td>使用服务:</td>\n");
	printf("<td>\n");
	printf("<select name='command_service'onchange='getvalue(this)'>\n");
	printf("<option>Check cpu</option>\n");
	printf("<option>Check file</option>\n");
	printf("<option>Check sql server</option>\n");
	printf("<option>Check application server</option>\n");
	printf("<option>Check ftp</option>\n");
	printf("<option>tar</option>\n");
	printf("<option>FTP info</option>\n");
	printf("<option>check mem</option>\n");
	printf("<option>check network</option>\n");
	printf("<option>check process</option>\n");
	printf("<option>check disk</option>\n");
	printf("<option>check serial</option>\n");
	printf("</select>\n");
	printf("</td\n>");
	printf("</tr>\n");

	//command arguments
	printf("<tr>\n");
	printf("<td>命令:</td>\n");
	printf("<td>\n");
	printf("<input type=text name='command_arguments' size=100 value='check_nrpe!check_cpu!\"-w 0.5,0.6,0.3,0.2,0.02 -c 0.7,0.8,0.4,0.3,0.05\"'>(参照文档)</input>");
	printf("</td\n>");
	printf("</tr>\n");

	//提交按钮
	printf("<tr align=center>\n");
	printf("<td colspan = 2>\n");
	printf("<input type='submit' value='添加'   />\n");
	printf("</tr>\n");

	printf("</table>\n");
	printf("</form>\n");
	printf("</div></p>\n");
}

void dealservice_init(){
	int result = 0;

	init_shared_cfg_vars(1);
	
	result = read_cgi_config_file(get_cgi_config_location());
	if(ERROR == result){
		document_header(FALSE);
		cgi_config_file_error(get_cgi_config_location());
		document_footer();
		exit(EXIT_FAILURE);
	}

	result = read_main_config_file(main_config_file);
	if(ERROR == result){
		document_header(FALSE);
		cgi_config_file_error(get_cgi_config_location());
		document_footer();
		exit(EXIT_FAILURE);
	}

	result = xconfiguation_init_config_data();
	if(ERROR == result){
		document_header(FALSE);
		cgi_config_file_error(get_cgi_config_location());
		document_footer();
		exit(EXIT_FAILURE);
	}
}

void document_header(int use_stylesheet) {
	char date_time[MAX_DATETIME_LENGTH];
	time_t t;


	time(&t);
	get_time_string(&t, date_time, sizeof(date_time), HTTP_DATE_TIME);

	printf("Cache-Control: no-store\r\n");
	printf("Pragma: no-cache\r\n");
	printf("Last-Modified: %s\r\n", date_time);
	printf("Expires: %s\r\n", date_time);
	printf("Content-type: text/html\r\n\r\n");

	printf("<html>\n");
	printf("<head>\n");
	printf("<link rel=\"shortcut icon\" href=\"%sfavicon.ico\" type=\"image/ico\">\n", url_images_path);
	printf("<META HTTP-EQUIV='Pragma' CONTENT='no-cache'>\n");
	printf("<title>\n");
	printf("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">");
	printf("Configuration\n");
	printf("</title>\n");

	printf("<script type='text/javascript' src='../js/dealservice.js'>\n");
	
	printf("</script>\n");

	if(use_stylesheet == TRUE) {
		printf("<LINK REL='stylesheet' TYPE='text/css' HREF='%s%s'>\n", url_stylesheets_path, COMMON_CSS);
		printf("<LINK REL='stylesheet' TYPE='text/css' HREF='%s%s'>\n", url_stylesheets_path, CONFIG_CSS);
	}

	printf("</head>\n");

	printf("<body CLASS='config'>\n");

	return;
}

void document_footer(void){

	printf("</body>\n");
	printf("</html>\n");

	return;
}

int process_cgivars(){
	char **variables;
	int error = FALSE;
	int x;
	char * request_method = NULL;

	//
	request_method = getenv("REQUEST_METHOD");
	if(!request_method){
		return TRUE;
	}
	else if(!strcmp(request_method,"GET") || !strcmp(request_method,"HEAD")){
		return TRUE;
	}
	else if(!strcmp(request_method,"POST") || !strcmp(request_method,"PUT")){
		method_type = METHOD_POST;
	}
	else{
		return TRUE;
	}
	//
	variables = getcgivars();
	for(x = 0; variables[x] != NULL; x++){

		
		if(!strcmp(variables[x],"playtype")){
			x++;
			if(!strcmp(variables[x],"modify")){
				display_type = DISPLAY_MODIFY;
			}
			else if(!strcmp(variables[x],"delete")){
				display_type = DISPLAY_DELETE;
			}
		}
		else if(!strcmp(variables[x],"service_id")){
			x++;
			id = atoi(variables[x]);
		}
		else if(!strcmp(variables[x],"command")||!strcmp(variables[x],"command_service")){
			x++;
			command_line = strdup(variables[x]);
		}
		else if(!strcmp(variables[x],"timepriod")){
			x++;
			time_priod = strdup(variables[x]);

		}
		else if(!strcmp(variables[x],"command_arguments")){
			x++;
			command_arguments = strdup(variables[x]);
		}
		else if(!strcmp(variables[x],"host_name")){
			x++;
			host_name = strdup(variables[x]);
		}

	}

	free_cgivars(variables);
	return error;
}

void deal_fail_info(const char *info){
	printf("<H1>Whoops!</H1>\n");
	printf("<P><STRONG><FONT COLOR='RED'>Error: deal %s about service info!</FONT></STRONG></P>\n", info);
	return;
}


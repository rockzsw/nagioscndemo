#include "../include/config.h"
#include "../include/common.h"
#include "../include/objects.h"
#include "../include/macros.h"
#include "../include/cgiutils.h"
#include "../include/cgiauth.h"
#include "../include/getcgi.h"
#include "../xdata/xconfiguationdeal.h"

#define HOST_INFO_LEN  33

char hostip[HOST_INFO_LEN] = "";
char hostname[HOST_INFO_LEN] = "";


#define HOSTINFOFILE      "/usr/local/nagios/etc/objects/hosts.cfg"                 // config file for saving the host name & IP
#define HOSTSRVFILE       "/usr/local/nagios/etc/objects/remotehosts.cfg"           // config file for saving the services host support

static nagios_macros *mac;
authdata current_authdata;
unsigned char isexist = 0;
unsigned int g_id = 0;
extern char   url_logo_images_path[MAX_FILENAME_LENGTH];
extern char   url_stylesheets_path[MAX_FILENAME_LENGTH];

typedef struct hostnode_struct 
{
    int node_id;
    int checked;                  // whether be selected to delete
    char hostname[HOST_INFO_LEN];
    char hostIP[HOST_INFO_LEN];
    struct hostnode_struct *next;
}HostNode;

HostNode *pHostList = NULL;;

int ishosts_exists(char *ip, char *name) 
{
    HostNode *temp_host = NULL;
    
    /* check all the hosts... */
    for(temp_host = pHostList; temp_host != NULL; temp_host = temp_host->next) 
    {
		if (strcmp(temp_host->hostIP, ip) == 0)
            return TRUE;

        if (strcmp(temp_host->hostname, name) == 0)
            return TRUE;
    }

    return FALSE;
}

int ishostip_valid(char *hostip) 
{
    char *valid_domain_chars = "0123456789.";    //only support IPv4 till now
    
    if ((strcmp(hostip, "") != 0) && (strlen(hostip) == strspn(hostip, valid_domain_chars)))
        return TRUE;

    return FALSE;
}


int add_hostnode(char *ipaddress, char *hostname)
{
    HostNode *newNode = NULL;
    HostNode *listPtr = NULL;
	
    if (strlen(hostname) < 1)
        return -1;

	if (ishosts_exists(ipaddress, hostname) == TRUE) {
		isexist = 1;
		return -1;
	}  //already exist
        
                
    listPtr = pHostList;
    if (NULL == listPtr )
        return -1;
    
    while (listPtr->next != NULL)
        listPtr = listPtr->next;

    newNode = malloc(sizeof(HostNode));
    if (NULL == newNode)
    {
        return -1;
    }
    memset(newNode, 0, sizeof(HostNode));
    newNode->node_id = g_id++;
    listPtr->next = newNode;
    strncpy(newNode->hostname, hostname, HOST_INFO_LEN -1);
    strncpy(newNode->hostIP, ipaddress, HOST_INFO_LEN -1);

    return 0;
}

void set_invalidhostnode(int hostid)
{
    HostNode *temp_host = NULL;

    for (temp_host = pHostList; temp_host != NULL; temp_host = temp_host->next) 
    {  
		printf("##temp host id::%d\n",temp_host->node_id);       
		if (temp_host->node_id == hostid)
        {
           temp_host->checked = 1;    //set valid, select by the page that will be deleted
           break;
        }
    }

    return;
}


void unauthorized_message(void) 
{

    printf("<P><DIV CLASS='errorMessage'>It appears as though you do not have permission to view the configuration information you requested...</DIV></P>\n");
    printf("<P><DIV CLASS='errorDescription'>If you believe this is an error, check the HTTP server authentication requirements for accessing this CGI<br>");
    printf("and check the authorization options in your CGI configuration file.</DIV></P>\n");

    return;
}

void document_header(int use_stylesheet) 
{
    char date_time[MAX_DATETIME_LENGTH];
    time_t t;

    time(&t);
    get_time_string(&t, date_time, sizeof(date_time), HTTP_DATE_TIME);

    printf("Cache-Control: no-store\r\n");
    printf("Pragma: no-cache\r\n");
    printf("Last-Modified: %s\r\n", date_time);
    printf("Expires: %s\r\n", date_time);
    printf("Content-type: text/html charset=utf-8\r\n\r\n");

    printf("<html>\n");
    printf("<head>\n");
    printf("<META HTTP-EQUIV='Pragma' CONTENT='no-cache'>\n");
    printf("<title>\n");
    printf("Configuration\n");
    printf("</title>\n");
	if(use_stylesheet == TRUE) {
		printf("<LINK REL='stylesheet' TYPE='text/css' HREF='%s%s'>\n", url_stylesheets_path, COMMON_CSS);
		printf("<LINK REL='stylesheet' TYPE='text/css' HREF='%s%s'>\n", url_stylesheets_path, CONFIG_CSS);
	}

    printf("</head>\n");
    printf("<body CLASS='config' >\n");

    /* include user SSI header */
    //include_ssi_files(CONFIG_CGI, SSI_HEADER);

    return;
 }


void document_footer(void) 
{
    /* include user SSI footer */
    //include_ssi_files(ADDHOST_CGI, SSI_FOOTER);

    printf("</body>\n");
    printf("</html>\n");

    return;
}

void display_hostnode(void) 
{
    HostNode *temp_host = NULL;
    
    printf("<br><br>\n");
    printf("<div>请填写要添加的终端信息</div>\n");

    printf("<script language=\"javascript\">");
    printf("function check()");
    printf("{ ");
    printf("  str = formdata.hostip.value;"); 
    printf("  str1 = formdata.hostname.value;"); 
    
    printf("  if (str.length != 0)"); 
    printf("  { ");
    printf("    str = str.match(/(\\d+)\\.(\\d+)\\.(\\d+)\\.(\\d+)/g);");  
    printf("    if (str == null)");
    printf("    { ");
    printf("        alert(\" IP地址输入错误\");"); 
    printf("        return false;");
    printf("     }");
    
    printf("     if (RegExp.$1>255 || RegExp.$2>255 || RegExp.$3>255 || RegExp.$4>255)");
    printf("     { ");
    printf("          alert(\"你输入的IP地址无效\");"); 
    printf("          return false;");
    printf("      }");

    printf("     if (str1.length == 0)"); 
    printf("     { ");
    printf("         alert(\"主机名不能为空\");"); 
    printf("         return false;");
    printf("     }");
    printf("     return true;"); 
    printf("  }");

    printf("   if (str1.length != 0)"); 
    printf("   { ");
    printf("       alert(\"主机IP不能为空 \");"); 
    printf("       return false;");
    printf("   }");
    
    printf("   return true;"); 
    printf("}");
    printf("</script>"); 
    
    printf("<FORM name=\"formdata\" onSubmit=\"return check()\"  methos='post' action=\"%s\">\n", ADDHOST_CGI);
	//
	printf("<table border=0 class='data'>\n");
	//
	printf("<tr>\n");
	printf("<td>\n");
    printf("IP:\n");
	printf("</td>\n");
	printf("<td>\n");
    printf("<INPUT NAME='hostip' SIZE='32'>");
    printf("</td>\n");
	printf("</tr>\n");
	printf("<tr>\n");
	printf("<td>Name:</td>\n");
	printf("<td>\n");
    printf("<INPUT NAME='hostname' SIZE='32'>");
	printf("</td>\n");
	printf("</tr>\n");
	printf("</table>\n");
	printf("</br></br>\n");
    printf("<div>请选择要删除的终端</div>");
	printf("<table border=0 class='data'>");
    /* check all the hosts... */
    for(temp_host = pHostList; temp_host != NULL; temp_host = temp_host->next) 
    {
        if (temp_host->checked == 1)
            continue;
		if(strlen(temp_host->hostname) < 1||strlen(temp_host->hostIP) < 1)
			continue;
        printf("<tr>");
        printf("<td><input type='checkbox' name='selectnode' value='%d'/></td> <td>Name: %s </td><td>IP: %s </td>",  temp_host->node_id, temp_host->hostname, temp_host->hostIP);
		printf("</tr>");

    }
	printf("</table>");
    printf("</br>\n");
    printf("<INPUT TYPE='SUBMIT' VALUE='提交' > ");
    printf("</FORM>");

    return;
}

int process_cgivars(void) 
{
    char **variables;
    int error = FALSE;
    int x;

    variables = getcgivars();

    for(x = 0; variables[x] != NULL; x++) 
    {
        /* do some basic length checking on the variable identifier to prevent buffer overflows */
        if(strlen(variables[x]) >= MAX_INPUT_BUFFER - 1) 
        {
            continue;
        }

        /* we found the input of the host ip */
        else if(!strcmp(variables[x], "hostip")) 
        {
            x++;
            if(variables[x] == NULL) 
            {
                error = TRUE;
                break;
            }
            strncpy(hostip, variables[x], sizeof(hostip) - 1);
        }

        /* we found the input of the host name */
        else if(!strcmp(variables[x], "hostname")) 
        {
            x++;
            if(variables[x] == NULL) 
            {
                error = TRUE;
                break;
            }
            strncpy(hostname, variables[x], sizeof(hostname) - 1);
        }

        /* we found the input of the host want to delete */
        else if(!strcmp(variables[x], "selectnode")) 
        {
            x++;
            if(variables[x] == NULL) 
            {
                error = TRUE;
                break;
            }
			//printf("## selectnode is :%d\n",atoi(variables[x]));
            set_invalidhostnode(atoi(variables[x]));
        }


        /* we received an invalid argument */
        else
            error = TRUE;

        }

    /* free memory allocated to the CGI variables */
    free_cgivars(variables);

    return error;
}

void get_hostnode()
{
    FILE *fd = NULL;
    char temp[HOST_INFO_LEN * 2] = "";
    char *strptr = NULL;
    char *hostname = NULL;
    char *hostIP = NULL;
    HostNode *listPtr = NULL;
    HostNode *newNode = NULL;
    
    pHostList = malloc(sizeof(HostNode));
    if (NULL == pHostList)
    {
        return;
    }
    listPtr = pHostList;
    newNode = pHostList;
    memset(newNode, 0, sizeof(HostNode));
    
    /* open the file */
    if((fd = fopen(HOSTINFOFILE, "r")) == NULL)
    {
        return;
    }

    while (feof(fd) != TRUE)
    {
        if (NULL == fgets(temp, HOST_INFO_LEN * 2, fd))
            return;

        if (NULL == newNode)
        {
            newNode = malloc(sizeof(HostNode));
            if (NULL == newNode)
            {
                return;
            }
            memset(newNode, 0, sizeof(HostNode));
            newNode->node_id = g_id;
            listPtr->next = newNode;
            newNode->checked = 1;
            listPtr = newNode;
        }
        /* the config file format is like below 
        define host{
            use       linux-server
            host_name Nagios_linux
            alias     Nagios_linux
            address   192.168.118.63
         }
        */
        if ((strptr = strstr(temp, "host_name")) != NULL)
        {
            strptr = strtok(strptr, " ");
            hostname = strtok(NULL, "\n");
			if (NULL != hostname){
				while (*hostname == ' ' || *hostname == '\t')
					hostname++;
				strncpy(listPtr->hostname, hostname, HOST_INFO_LEN -1);
				g_id ++;
			}
			
        }

        if ((strptr = strstr(temp, "address")) != NULL)
        {
            strptr = strtok(strptr, " ");
            hostIP = strtok(NULL, "\n");

            if (NULL != hostIP)
            {
				while (*hostIP == ' ' || *hostIP == '\t')
					hostIP++;
				strncpy(listPtr->hostIP, hostIP, HOST_INFO_LEN -1);
                newNode->checked = 0;
                newNode = listPtr->next;
            }
        }
    }

    listPtr = pHostList;
    while (listPtr != NULL)
    {
        newNode = listPtr->next;
        if ((NULL != newNode) && (newNode->checked == 1))  // unused node
        {
            listPtr->next = newNode->next;
            free(newNode);
        }
        listPtr = listPtr->next;
    }
}

void write_hostnode_cfgfile()
{
    FILE *fd = 0;
    char temp[HOST_INFO_LEN * 2] = "";
    HostNode *temp_host = NULL;
	unsigned char typedelete = 0,typeadd = 0;

    xconfiguation_init_config_data();
    /* open the file */
    if ((fd = fopen(HOSTINFOFILE, "w")) == NULL)  // replace the old file 
    {
        return;
    }
    /* check all the hosts... */
    for(temp_host = pHostList; temp_host != NULL; temp_host = temp_host->next) 
    {   
        if (temp_host->checked == 1)   // skip the valid or selected node
		{
			
			if(temp_host->hostname){
				xconfiguation_delete_service_data_by_host_name(temp_host->hostname);
				typedelete = 1;
			}

			continue;
		}

        /* the config file format is like below 
        define host{
            use       linux-server
            host_name Nagios_linux
            alias     Nagios_linux
            address   192.168.118.63
         }
        */
		//printf("##hostname::%s# hostIP::%s#\n",temp_host->hostname,temp_host->hostIP);
		if(strlen(temp_host->hostname) < 1 || strlen(temp_host->hostIP) < 1)
			continue;
        snprintf(temp, sizeof(temp) - 1, "\n\ndefine host{");
        fwrite(temp, 1, strlen(temp), fd);
        snprintf(temp, sizeof(temp) - 1, "\n    use       linux-server,host-pnp");
        fwrite(temp, 1, strlen(temp), fd);
        snprintf(temp, sizeof(temp) - 1, "\n    host_name %s",  temp_host->hostname);
        fwrite (temp, 1, strlen(temp), fd);
        snprintf(temp, sizeof(temp) - 1, "\n    alias     %s",  temp_host->hostname);
        fwrite (temp, 1, strlen(temp), fd);
        snprintf(temp, sizeof(temp) - 1, "\n    address   %s",  temp_host->hostIP);
        fwrite (temp, 1, strlen(temp), fd);
        snprintf(temp, sizeof(temp) - 1, "\n}");
        fwrite(temp, 1, strlen(temp), fd);   


    }
    fclose (fd);
	//printf("isexist:%d hostname:%s hostip:%s\n",isexist,hostname,hostip);
	if(0 == isexist && strlen(hostname) >0 && strlen(hostip) > 1)
	 typeadd |= xconfiguation_add_default_service_data(hostname,hostip);
	
	//printf("typeadd: %d typedel:%d\n",typeadd,typedelete);
	if(1 == typedelete || 1 == typeadd)
		xconfiguation_write_service_config_data();
	xconfiguation_clear_memory();
    return;
}

// handle add host IP&Name  via the html page
int main()
{
    HostNode *temp_host = NULL;
    
    /* reset internal variables */
    reset_cgi_vars();

    mac = get_global_macros();
    cgi_init(document_header, document_footer, READ_ALL_OBJECT_DATA, 0);

    /* get authentication information */
    get_authentication_information(&current_authdata);
    if(is_authorized_for_configuration_information(&current_authdata) == FALSE) 
    {
        unauthorized_message();
        return 1;
    }
	//printf("Content-type:text/html\n\n");
	
    get_hostnode();
    process_cgivars();
    if (0 != add_hostnode(hostip, hostname))
    {
       // printf("Content-type:text/html\n\n");
       // printf("Add host failed %s %s\n", hostip, hostname);
		//printf("Add host failed #%s# #%s# len %d\n", hostip, hostname,strlen(hostname));
    }
    
    document_header(TRUE);
     /* begin top table */
    printf("<table border=0 width=100%%>\n");
    printf("<tr>\n");

    /* left column of the first row */
    printf("<td align=left valign=top width=50%%>\n");
    //display_info_table("Configuration", FALSE, &current_authdata);
    printf("</td>\n");

    /* right hand column of top row */
    printf("<td align=right valign=bottom width=50%%>\n");
    printf("</td>\n");

    display_hostnode();
    write_hostnode_cfgfile();    
    /* end of top table */
    printf("</tr>\n");
    printf("</table>\n");
    document_footer();


    
    for (temp_host = pHostList; temp_host != NULL; temp_host = temp_host->next) 
    {
        free(temp_host);
    }
    
    return 0;
}



